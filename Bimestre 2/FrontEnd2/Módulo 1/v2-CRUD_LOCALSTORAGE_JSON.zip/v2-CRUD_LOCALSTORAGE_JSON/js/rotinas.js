document.addEventListener("onload", executarRotinas() ); //
function executarRotinas() {
    var localStorageKeyName = 'data';

    carregarDoLocalStorage();

    document.querySelector("#btn-add").addEventListener('click', function () {
        var nome = document.getElementById("nome"),
            email = document.getElementById("email"),
            idade = document.getElementById("idade");

        // Validar
        if (nome.value.length === 0 || email.value.length === 0 || !parseInt(idade.value)) return;

        var usuario = {
            nome: nome.value,
            email: email.value,
            idade: idade.value
        };

        // Limpar dados
        nome.value = '';
        email.value = '';
        idade.value = '';

        // Adicionar ao localStorage
        adicionarAoLocalStorage(usuario);
    })

    function adicionarAoLocalStorage(obj) {
        var usuarios = [],
            dadosNoLocalStorage = localStorage.getItem(localStorageKeyName);

        if (dadosNoLocalStorage !== null) {
            usuarios = JSON.parse(dadosNoLocalStorage);
        }

        usuarios.push(obj);

        localStorage.setItem(localStorageKeyName, JSON.stringify(usuarios));

        carregarDoLocalStorage();
    }

    function carregarDoLocalStorage() {
        var usuarios = [],
            dadosNoLocalStorage = localStorage.getItem(localStorageKeyName),
            gridBody = document.querySelector("#grid tbody");

        if (dadosNoLocalStorage !== null) {
            usuarios = JSON.parse(dadosNoLocalStorage);
        }

        // Draw TR from TBODY
        gridBody.innerHTML = '';

        usuarios.forEach(function (x, i) {
            var tr = document.createElement("tr"),
                tdName = document.createElement("td"),
                tdJob = document.createElement("td"),
                tdAge = document.createElement("td"),
                tdRemove = document.createElement("td"),
                btnRemove = document.createElement("button");

            tdName.innerHTML = x.nome;
            tdJob.innerHTML = x.email;
            tdAge.innerHTML = x.idade;

            btnRemove.textContent = 'Remove';
            btnRemove.className = 'btn btn-xs btn-danger';
            btnRemove.addEventListener('click', function(){
                removeFromLocalStorage(i);
            });

            tdRemove.appendChild(btnRemove);

            tr.appendChild(tdName);
            tr.appendChild(tdJob);
            tr.appendChild(tdAge);
            tr.appendChild(tdRemove);

            gridBody.appendChild(tr);
        });
    }

    function removeFromLocalStorage(index){
        var usuarios = [],
            dadosNoLocalStorage = localStorage.getItem(localStorageKeyName);

        usuarios = JSON.parse(dadosNoLocalStorage);

        usuarios.splice(index, 1);

        localStorage.setItem(localStorageKeyName, JSON.stringify(usuarios));

        carregarDoLocalStorage();
    }
}